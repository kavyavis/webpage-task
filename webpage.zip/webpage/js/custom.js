$(document).ready(function () {
  $(".hero").slick({
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    arrows: true,
    nextArrow:
      '<div class="slick-custom-arrow slick-custom-arrow-right"><img src="images/arrow.svg" alt="arrow left"></div>',
    prevArrow:
      '<div class="slick-custom-arrow slick-custom-arrow-left"><img src="images/arrow.svg" alt="arrrow right"></div>',
  });
});

/* we stay connected  slider */
$(document).ready(function () {
  $(".stay-slider").slick({
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    arrows: true,
    nextArrow:
      '<div class="slick-custom-arrow slick-custom-arrow-right"><img src="images/arrow.svg" alt="arrow left"></div>',
    prevArrow:
      '<div class="slick-custom-arrow slick-custom-arrow-left"><img src="images/arrow.svg" alt="arrrow right"></div>',
  });
});

/* story  slider */
$(document).ready(function () {
  $(".story-slider").slick({
    infinite: true,
    speed: 300,
    slidesToShow: 1,
    arrows: true,
    nextArrow:
      '<div class="slick-custom-arrow slick-custom-arrow-right"><img src="images/arrow.svg" alt="arrow left"></div>',
    prevArrow:
      '<div class="slick-custom-arrow slick-custom-arrow-left"><img src="images/arrow.svg" alt="arrrow right"></div>',
  });
});

//  header fixed after page scroll
$(window).scroll(function () {
  var sticky = $(".sticky"),
    scroll = $(window).scrollTop();
  if (scroll >= 100) sticky.addClass("header-fixed");
  else sticky.removeClass("header-fixed");
});
